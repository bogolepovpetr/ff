-- Run once from the Studio Command Bar AFTER fitting the imported armor.
-- Expected Workspace models: ArmorFitRig (a block R15), HeroismArmor (imported FBX).
-- This preserves each fitted part's world placement; it does not auto-fit or scale.
local rig = assert(workspace:FindFirstChild("ArmorFitRig"), "Create/rename your R15 rig: ArmorFitRig")
local armor = assert(workspace:FindFirstChild("HeroismArmor"), "Rename the imported armor model: HeroismArmor")
local pairsToWeld = {}
for _, mesh in ipairs(armor:GetDescendants()) do
    if mesh:IsA("MeshPart") then
        local bodyName = mesh.Name:match("^Armor_(.+)$")
        local body = bodyName and rig:FindFirstChild(bodyName)
        assert(body and body:IsA("BasePart"), "Unknown armor/body part: " .. mesh.Name)
        table.insert(pairsToWeld, {mesh, body})
    end
end
assert(#pairsToWeld == 15, "Expected 15 MeshParts; check that the importer preserved separate meshes and names")
for _, pair in ipairs(pairsToWeld) do
    local mesh, body = pair[1], pair[2]
    mesh.Anchored = false
    mesh.CanCollide = false
    mesh.CanTouch = false
    mesh.CanQuery = false
    mesh.Massless = true
    local old = mesh:FindFirstChild("ArmorBodyWeld")
    if old then old:Destroy() end
    local weld = Instance.new("WeldConstraint")
    weld.Name = "ArmorBodyWeld"
    weld.Part0 = body
    weld.Part1 = mesh
    weld.Parent = mesh
end
armor.Parent = rig
print("Fitted armor welded to R15: " .. #pairsToWeld .. " parts")
