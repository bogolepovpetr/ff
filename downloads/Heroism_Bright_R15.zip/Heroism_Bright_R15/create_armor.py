import bpy, math, os, json
from mathutils import Vector
import numpy as np

OUT = '/workspace/roblox_heroism/output'
os.makedirs(OUT, exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for block in list(bpy.data.materials): bpy.data.materials.remove(block)
scene=bpy.context.scene
scene.unit_settings.system='NONE'
armor=bpy.data.collections.new('ARMOR • R15 rigid parts'); scene.collection.children.link(armor)
guide=bpy.data.collections.new('REFERENCE • approximate block R15 • do not export'); scene.collection.children.link(guide)
studio=bpy.data.collections.new('STUDIO • do not export'); scene.collection.children.link(studio)

# A shared UV atlas: two columns by three rows; real PBR channels, no painted highlights.
N=1024
palette=[('Azure enamel',(0.025,.26,.46),.72,.27),('Polished gold',(.78,.43,.065),.86,.22),('Brushed steel',(.34,.48,.56),.88,.38),('Dark leather',(.035,.052,.068),0,.84),('Turquoise inlay',(.02,.64,.57),.4,.19),('Recessed iron',(.045,.075,.105),.82,.61)]
yy,xx=np.mgrid[0:N,0:N]; col=(xx>=N//2).astype(int); row=np.minimum(yy//(N//3+1),2); tile=row*2+col
rng=np.random.default_rng(82); noise=rng.normal(0,1,(N,N))
grain=np.sin(xx*.85+np.sin(yy*.055))*np.sin(yy*.33)
rgba={k:np.ones((N,N,4),dtype=np.float32) for k in ['BaseColor','Metalness','Roughness','Normal']}
for k,(name,c,m,r) in enumerate(palette):
 mask=tile==k
 variation=1+noise*.017+grain*.012
 for ch in range(3):
  rgba['BaseColor'][:,:,ch][mask]=np.clip(c[ch]*variation[mask],0,1)
  rgba['Metalness'][:,:,ch][mask]=m
  rgba['Roughness'][:,:,ch][mask]=np.clip(r+noise[mask]*.018+grain[mask]*.012,.05,1)
 rgba['Normal'][:,:,0][mask]=.5+grain[mask]*.025
 rgba['Normal'][:,:,1][mask]=.5+noise[mask]*.014
 rgba['Normal'][:,:,2][mask]=1
images={}
for channel,array in rgba.items():
 im=bpy.data.images.new('Armor_'+channel,width=N,height=N,alpha=True)
 im.colorspace_settings.name='sRGB' if channel=='BaseColor' else 'Non-Color'
 im.pixels.foreach_set(array.ravel()); im.filepath_raw=os.path.join(OUT,'Armor_'+channel+'.png'); im.file_format='PNG'; im.save(); images[channel]=im
mat=bpy.data.materials.new('Heroism • shared PBR atlas'); mat.use_nodes=True
nodes=mat.node_tree.nodes; bs=nodes.get('Principled BSDF'); bs.inputs['Coat Weight'].default_value=.12
for i,(channel,im) in enumerate(images.items()):
 t=nodes.new('ShaderNodeTexImage'); t.image=im; t.location=(-600,250-i*230); t.label=channel
 if channel=='Normal':
  n=nodes.new('ShaderNodeNormalMap'); n.inputs['Strength'].default_value=.3; n.location=(-220,-400)
  mat.node_tree.links.new(t.outputs['Color'],n.inputs['Color']); mat.node_tree.links.new(n.outputs['Normal'],bs.inputs['Normal'])
 else: mat.node_tree.links.new(t.outputs['Color'],bs.inputs[{'BaseColor':'Base Color','Metalness':'Metallic','Roughness':'Roughness'}[channel]])

parts={}; active_part=''; current=[]
def move(obj,collection):
 for c in list(obj.users_collection): c.objects.unlink(obj)
 collection.objects.link(obj)
def finish(obj,name,tile_id,bevel=0):
 obj.name=name; move(obj,armor)
 bpy.context.view_layer.objects.active=obj
 obj.select_set(True)
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=obj.modifiers.new('Forged rounded edges','BEVEL'); mod.width=bevel; mod.segments=2
  bpy.ops.object.modifier_apply(modifier=mod.name)
 bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.uv.smart_project(island_margin=.02); bpy.ops.object.mode_set(mode='OBJECT')
 for uv in obj.data.uv_layers.active.data:
  uv.uv.x=(tile_id%2+0.04+uv.uv.x*.92)/2
  uv.uv.y=(tile_id//2+0.04+uv.uv.y*.92)/3
 obj.data.materials.clear(); obj.data.materials.append(mat)
 current.append(obj); obj.select_set(False)
 return obj
def box(name,loc,scale,t=0,b=.04,rot=(0,0,0)):
 bpy.ops.object.select_all(action='DESELECT'); bpy.ops.mesh.primitive_cube_add(size=1,location=loc,rotation=rot)
 o=bpy.context.object; o.scale=scale; return finish(o,name,t,b)
def gem(name,loc,scale,t=4):
 bpy.ops.object.select_all(action='DESELECT'); bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=loc)
 o=bpy.context.object; o.scale=scale; return finish(o,name,t)
def rod(name,a,b,r1,r2,t=1,verts=8):
 a,b=Vector(a),Vector(b); d=b-a
 bpy.ops.object.select_all(action='DESELECT'); bpy.ops.mesh.primitive_cone_add(vertices=verts,radius1=r1,radius2=r2,depth=d.length,location=(a+b)/2)
 o=bpy.context.object; o.rotation_euler=d.to_track_quat('Z','Y').to_euler(); return finish(o,name,t,.008 if r2 else 0)
def rivet(x,y,z,r=.035):
 gem('Hand hammered rivet',(x,y,z),(r,r*.55,r),1)
def plate(name,points,y,depth,t=0):
 # Profile in X/Z, with real extrusion and beveled silhouette.
 n=len(points); verts=[(x,y,z) for x,z in points]+[(x,y+depth,z) for x,z in points]
 faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new(name); mesh.from_pydata(verts,[],faces); mesh.update()
 ob=bpy.data.objects.new(name,mesh); armor.objects.link(ob); return finish(ob,name,t,.025)
def start(name):
 global active_part,current
 active_part=name; current=[]
def end(center,bodypart):
 bpy.ops.object.select_all(action='DESELECT')
 for o in current: o.select_set(True)
 bpy.context.view_layer.objects.active=current[0]; bpy.ops.object.join(); ob=bpy.context.object; ob.name=active_part
 scene.cursor.location=center; bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
 ob['R15_BodyPart']=bodypart; ob['Attachment_Notes']='Rigid MeshPart. Match position to reference and weld to indicated R15 body part. Not a layered clothing cage.'
 parts[active_part]=ob; ob.select_set(False)

# Chest shell: front/back panels and side connectors leave a neck opening.
start('Armor_UpperTorso')
box('Padded underplate',(0,0,3.65),(2.04,1.05,1.27),5,.08)
box('Breastplate gold border',(0,-.559,3.68),(1.91,.13,1.15),1,.10)
plate('Azure cuirass',[(-.87,4.18),(.87,4.18),(.85,3.45),(.38,3.14),(-.38,3.14),(-.85,3.45)],-.665,.12,0)
for s in [-1,1]:
 for i in range(3):
  rod('Raised chevron',(s*.08,-.71,3.89-i*.19),(s*.67,-.69,4.03-i*.19),.021,.021,1)
 for z in [3.47,3.76,4.08]: rivet(s*.75,-.72,z)
 box('Side buckle',(s*1.04,0,3.55),(.1,.76,.13),1,.025)
 rod('Neck rim',(s*.12,-.62,4.21),(s*.85,-.58,4.23),.055,.055,1)
gem('Cuirass crest surround',(0,-.75,3.91),(.28,.085,.32),1)
gem('Cuirass crest turquoise',(0,-.825,3.92),(.19,.065,.23))
for z in [3.42,3.67,3.92]: box('Back segmented plate',(0,.575,z),(1.8,.14,.21),0,.035)
rod('Back spine',(0,.69,3.27),(0,.69,4.2),.045,.045,1)
end((0,0,3.65),'UpperTorso')

start('Armor_LowerTorso')
box('Leather belt',(0,0,2.87),(2.08,1.12,.35),3,.06)
for s in [-1,1]:
 box('Gilded belt side',(s*.64,-.59,2.88),(.67,.10,.23),1,.03)
 for x in [.45,.7,.91]: rivet(s*x,-.67,2.88)
box('Buckle',(0,-.65,2.88),(.48,.17,.34),1,.04)
gem('Belt jewel',(0,-.76,2.88),(.15,.06,.12))
end((0,0,2.87),'LowerTorso')

for s,side in [(-1,'Right'),(1,'Left')]:
 start('Armor_'+side+'UpperArm')
 # Three overlapping shoulder tiers, iconic oversized silhouette.
 for i in range(3):
  x=s*(1.37+i*.23); z=4.25-i*.15
  box('Pauldrons gilded rim',(x,0,z),(.83,.1+1.25-i*.09,.29),1,.075,rot=(0,s*-.2,0))
  box('Pauldrons enamel',(x,-.015,z+.06),(.72,1.15-i*.09,.24),0,.065,rot=(0,s*-.2,0))
  for y in [-.54,.5]: rivet(x,y,z+.07,.043)
 # Curved steel shoulder blades with gold roots.
 for y in [-.36,.08,.45]:
  a=(s*1.61,y,4.43); b=(s*1.91,y+.02,4.76); c=(s*2.10,y+.05,4.94)
  rod('Spike gilded socket',a,(s*1.71,y,4.55),.14,.105,1)
  rod('Forged shoulder spike',a,b,.105,.065,2)
  rod('Forged spike tip',b,c,.065,0,2)
 box('Upper arm padded sleeve',(s*1.52,0,3.78),(.86,.93,.62),3,.06)
 box('Bicep blue plate',(s*1.52,-.49,3.78),(.7,.12,.56),0,.05)
 rod('Bicep gilt groove',(s*1.25,-.57,3.83),(s*1.78,-.57,3.83),.024,.024,1)
 end((s*1.5,0,3.87),side+'UpperArm')

 start('Armor_'+side+'LowerArm')
 box('Bracer leather',(s*1.5,0,2.97),(.88,.96,.78),3,.06)
 for z in [2.64,3.26]: box('Bracer polished cuff',(s*1.5,0,z),(.97,1.03,.12),1,.03)
 box('Vambrace border',(s*1.5,-.53,2.98),(.85,.15,.66),1,.06)
 plate('Vambrace enamel',[(s*1.5-.33,3.25),(s*1.5+.33,3.25),(s*1.5+.29,2.82),(s*1.5,2.64),(s*1.5-.29,2.82)],-.64,.09,0)
 gem('Bracer inlay',(s*1.5,-.71,3.01),(.10,.04,.20))
 for dx in [-.28,.28]: rivet(s*1.5+dx,-.69,3.17)
 end((s*1.5,0,2.97),side+'LowerArm')

 start('Armor_'+side+'Hand')
 box('Gauntlet',(s*1.5,-.03,2.34),(.88,.98,.39),5,.07)
 for i in range(3): box('Articulated finger plate',(s*1.5,-.54,2.48-i*.11),(.77,.11,.085),2,.025)
 for dx in [-.25,0,.25]: gem('Knuckle stud',(s*1.5+dx,-.62,2.46),(.055,.04,.045),1)
 end((s*1.5,0,2.34),side+'Hand')

 start('Armor_'+side+'UpperLeg')
 x=s*.51
 box('Thigh padded shell',(x,0,1.99),(.96,1.01,.93),3,.05)
 for i in range(3):
  z=2.37-i*.24
  box('Tasset gold border',(x,-.57,z),(.91,.13,.30),1,.035)
  box('Overlapping tasset',(x,-.66,z+.015),(.79,.09,.23),0,.03)
  for dx in [-.31,.31]: rivet(x+dx,-.725,z+.065,.027)
 box('Outer thigh trim',(s*1.01,0,2.08),(.1,.92,.72),1,.025)
 end((x,0,1.99),side+'UpperLeg')

 start('Armor_'+side+'LowerLeg')
 box('Shin shell',(x,0,1.02),(.95,1.04,.89),5,.06)
 plate('Gilded greave',[(x-.45,1.46),(x,1.64),(x+.45,1.46),(x+.38,.58),(x-.38,.58)],-.59,.11,1)
 plate('Azure shin',[(x-.34,1.42),(x,1.55),(x+.34,1.42),(x+.27,.65),(x-.27,.65)],-.715,.09,0)
 rod('Greave raised keel',(x,-.83,.71),(x,-.83,1.40),.035,.035,2)
 gem('Knee jewel',(x,-.84,1.43),(.12,.04,.12))
 for dx in [-.28,.28]: rivet(x+dx,-.83,.77)
 box('Rear shin plate',(x,.57,1.03),(.72,.13,.72),0,.035)
 end((x,0,1.02),side+'LowerLeg')

 start('Armor_'+side+'Foot')
 box('Boot leather',(x,-.08,.34),(.97,1.24,.46),3,.07)
 box('Sabatons gold rim',(x,-.21,.25),(1.04,1.49,.20),1,.06)
 box('Armored toe',(x,-.37,.39),(.97,1.12,.25),0,.07)
 for y in [-.66,-.38,-.1]: box('Toe articulated steel',(x,y,.53),(.9,.055,.045),2,.015)
 end((x,0,.34),side+'Foot')

start('Armor_Head')
# Open face and open underside; no solid cube around the face.
box('Helmet crown',(0,.03,5.53),(1.20,1.15,.20),0,.09)
box('Helmet back',(0,.54,5.14),(1.15,.18,.76),0,.06)
for s in [-1,1]:
 box('Helmet temple',(s*.56,.02,5.17),(.19,1.05,.67),0,.06)
 rod('Helmet brow',(s*.04,-.59,5.44),(s*.55,-.56,5.40),.057,.057,1)
 plate('Cheek guard',[(s*.55,5.20),(s*.38,4.80),(s*.64,4.88)],-.57,.19,1)
 a=(s*.56,.08,5.39); b=(s*.88,.08,5.70); c=(s*1.0,.12,6.03); d=(s*.87,.16,6.23)
 rod('Horn socket',a,(s*.67,.08,5.48),.17,.14,1)
 rod('Curved horn base',a,b,.13,.105,2); rod('Curved horn mid',b,c,.105,.06,2); rod('Curved horn tip',c,d,.06,0,1)
gem('Helmet turquoise crest',(0,-.62,5.46),(.13,.05,.17))
rod('Crown center ridge',(0,-.45,5.67),(0,.49,5.67),.055,.055,1)
end((0,0,5.07),'Head')

# A neutral mannequin is an explicit reference, never part of armor export.
refmat=bpy.data.materials.new('Mannequin • matte warm gray'); refmat.diffuse_color=(.16,.20,.23,1); refmat.use_nodes=True; refmat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.16,.20,.23,1); refmat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.9
def refbox(name,loc,size):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.name='REFERENCE_'+name; o.scale=size
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 be=o.modifiers.new('Soft edges','BEVEL'); be.width=.055; be.segments=3
 o.data.materials.append(refmat); move(o,guide)
refbox('Head',(0,0,5.06),(1.02,1.02,.94))
refbox('UpperTorso',(0,0,3.65),(1.95,.96,1.25)); refbox('LowerTorso',(0,0,2.86),(1.94,.97,.34))
for s,side in [(-1,'Right'),(1,'Left')]:
 for name,z,h,w,d in [('UpperArm',3.87,1.12,.80,.84),('LowerArm',2.97,.76,.80,.84),('Hand',2.34,.39,.80,.88)]: refbox(side+name,(s*1.5,0,z),(w,d,h))
 for name,z,h in [('UpperLeg',1.99,.99),('LowerLeg',1.02,.90),('Foot',.34,.45)]: refbox(side+name,(s*.51,0,z),(.90,.94,h))

# Export only rigid armor meshes, keep named objects and body-local origins.
bpy.ops.object.select_all(action='DESELECT')
for ob in parts.values():
 ob.select_set(True); bpy.context.view_layer.objects.active=ob
 # Triangulation is explicit and stable for Roblox import.
 mod=ob.modifiers.new('Export triangulation','TRIANGULATE'); bpy.ops.object.modifier_apply(modifier=mod.name)
 ob.select_set(False)
for ob in parts.values(): ob.select_set(True)
bpy.ops.export_scene.fbx(filepath=os.path.join(OUT,'Heroism_Bright_R15.fbx'),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',apply_unit_scale=True,bake_anim=False,path_mode='COPY',embed_textures=False)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'Heroism_Bright_R15.glb'),use_selection=True,export_format='GLB',export_apply=True)
os.makedirs(os.path.join(OUT,'parts'),exist_ok=True)
for name,ob in parts.items():
 bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True)
 bpy.ops.export_scene.fbx(filepath=os.path.join(OUT,'parts',name+'.fbx'),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_anim=False,path_mode='AUTO')
manifest={name:{'body_part':ob['R15_BodyPart'],'origin_blender_xyz':list(ob.location),'triangles':len(ob.data.polygons)} for name,ob in parts.items()}
with open(os.path.join(OUT,'parts_manifest.json'),'w') as f: json.dump({'reference':'Approximate standard block R15. Fit in Studio before welding. Blender XYZ is exported as Roblox X,-Z,Y.','parts':manifest,'total_triangles':sum(v['triangles'] for v in manifest.values())},f,indent=2)

# Studio lighting. Rendered highlights come from metalness/roughness.
floor=bpy.data.materials.new('Backdrop'); floor.diffuse_color=(.025,.04,.065,1)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,.06)); o=bpy.context.object; o.name='Studio floor'; o.data.materials.append(floor); move(o,studio)
def light(name,loc,power,color,size):
 bpy.ops.object.light_add(type='AREA',location=loc); o=bpy.context.object; o.name=name; o.data.energy=power; o.data.color=color; o.data.shape='DISK'; o.data.size=size; o.rotation_euler=(Vector((0,0,3))-o.location).to_track_quat('-Z','Y').to_euler(); move(o,studio)
light('Large warm key',(4,-6,9),1200,(1,.88,.73),5)
light('Cool fill',(-5,-3,5),900,(.60,.80,1),4)
light('Rim',(2,4,8),1600,(.55,.85,1),3)
scene.world.color=(.15,.15,.15)
bpy.ops.object.camera_add(location=(8,-15,8)); cam=bpy.context.object; move(cam,studio); scene.camera=cam
cam.rotation_euler=(Vector((0,0,3.1))-cam.location).to_track_quat('-Z','Y').to_euler(); cam.data.type='ORTHO'; cam.data.ortho_scale=8.0
scene.render.engine='CYCLES'; scene.cycles.samples=96; scene.cycles.use_denoising=False
scene.render.resolution_x=1200; scene.render.resolution_y=1200; scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
for im in images.values(): im.pack()
bpy.ops.object.select_all(action='DESELECT')
for ob in parts.values(): ob.select_set(True)
bpy.context.view_layer.objects.active=parts['Armor_UpperTorso']
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':
  area.spaces.active.region_3d.view_distance=10
  area.spaces.active.region_3d.view_location=(0,0,3)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'Heroism_Bright_R15.blend'))
scene.render.filepath=os.path.join(OUT,'Preview_Front.png'); bpy.ops.render.render(write_still=True)
cam.location=(-8,13,7); cam.rotation_euler=(Vector((0,0,3.1))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=os.path.join(OUT,'Preview_Back.png'); bpy.ops.render.render(write_still=True)
print('COMPLETE',sum(v['triangles'] for v in manifest.values()),'triangles',len(parts),'parts')
